# ABYSSAL – Portal Template (Bedrock Edition)

Dies ist eine **Starter-Vorlage**, kein fertig getestetes Add-on. Sie enthält:
- Behavior-Pack-Grundgerüst mit Script-API-Beispiel
- zentrale Portal-Konfiguration für F, E, D, C, B, A, S und SS
- Resource-Pack-Grundgerüst mit Beispiel-Animationsdateien
- Hinweise zur Integration und zu notwendigen Tests

## Wichtig vor dem Einsatz
1. Prüfe die Minecraft-Bedrock-Version und die dazu passende `@minecraft/server`-Version.
2. Passe die Dependency-Version im `BP/manifest.json` an deine installierte stabile API an.
3. Ergänze die acht Dimension-Definitionen in deinem bestehenden Projekt. Die IDs müssen exakt übereinstimmen.
4. Erstelle in Blockbench ein Modell mit den Bones `portal_surface` und `portal_glow`.
5. Erstelle die fehlenden PNG-Texturen und ergänze die Client-Entity/Render-Controller-Dateien.
6. Prüfe alle Dateien in einer separaten Testwelt, bevor du sie in einer bestehenden Welt verwendest.

## Testverhalten
Der Script-Prototyp reagiert auf die Interaktion mit einem Lodestone **nur an einer konfigurierten Testposition**. Das ist absichtlich ein temporärer Auslöser, kein finales Portalmodell.

Vor dem Teleport wird versucht, eine sichere Plattform am Ziel zu bauen. Das ist für einen echten Dungeon-Betrieb nur eine einfache Testlösung: In einer finalen Version sollten vorbereitete, geschützte Spawn-Bereiche verwendet werden, statt bei jedem Teleport Blöcke zu verändern.

Der Rückweg führt in dieser Vorlage zu einer festgelegten Overworld-Position. Speichern der individuellen Rückkehrposition, Rangprüfung, Gruppeninstanzen und Anti-Exploit-Logik sind noch zu implementieren.

## Ordner
- `BP/`: Gameplay-Logik und Konfiguration
- `RP/`: Animationen und Resource-Pack-Grundstruktur

## Nicht enthalten
- fertige Blockbench-Geometrie
- fertige PNG-Texturen
- fertige Sounds
- vollständige Client-Entity-/Render-Controller-Einbindung
- produktionsreifes Rang-, Gruppen- oder Dungeon-System

Die Animationen sind Beispiele und müssen an das tatsächlich erstellte Modell angepasst werden.
