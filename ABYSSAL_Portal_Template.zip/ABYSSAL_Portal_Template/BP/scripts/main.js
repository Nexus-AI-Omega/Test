import { world, system } from "@minecraft/server";

/*
 * ABYSSAL Portal Starter
 * - Test trigger: Lodestone at exactly one configured Overworld coordinate.
 * - Destination and return point are placeholders; adapt them to your project.
 * - This is a prototype, not a production-ready dungeon transport system.
 */

const CONFIG = {
    trigger: {
        dimension: "minecraft:overworld",
        block: "minecraft:lodestone",
        x: 10, y: 64, z: 10
    },
    destination: {
        dimension: "abyssal:f_dimension",
        x: 0.5, y: 81, z: 0.5
    },
    returnPoint: {
        dimension: "minecraft:overworld",
        x: 0.5, y: 80, z: 0.5
    },
    cooldownTicks: 40
};

const busyPlayers = new Set();

function tell(player, message) {
    player.sendMessage(`§8[§5ABYSSAL§8] §r${message}`);
}

function sameLocation(block, expected) {
    return block.dimension.id === expected.dimension &&
        block.location.x === expected.x &&
        block.location.y === expected.y &&
        block.location.z === expected.z &&
        block.typeId === expected.block;
}

function ensureSafeArrival(dimension, x, y, z) {
    // Small, flat test platform. Use prebuilt protected spawn rooms in production.
    for (let dx = -2; dx <= 2; dx++) {
        for (let dz = -2; dz <= 2; dz++) {
            const floor = dimension.getBlock({ x: x + dx, y: y - 1, z: z + dz });
            const feet = dimension.getBlock({ x: x + dx, y, z: z + dz });
            const head = dimension.getBlock({ x: x + dx, y: y + 1, z: z + dz });

            if (!floor || !feet || !head) return false;

            // Do not overwrite non-air blocks in the arrival volume.
            if (feet.typeId !== "minecraft:air" ||
                head.typeId !== "minecraft:air") {
                return false;
            }
        }
    }

    for (let dx = -2; dx <= 2; dx++) {
        for (let dz = -2; dz <= 2; dz++) {
            dimension.getBlock({ x: x + dx, y: y - 1, z: z + dz })
                .setType("minecraft:stone_bricks");
        }
    }
    return true;
}

async function teleport(player, target) {
    if (busyPlayers.has(player.id)) return;
    busyPlayers.add(player.id);

    try {
        const dimension = world.getDimension(target.dimension);

        // Check that the destination chunk/area is accessible before teleporting.
        const safe = ensureSafeArrival(
            dimension,
            Math.floor(target.x),
            Math.floor(target.y),
            Math.floor(target.z)
        );

        if (!safe) {
            tell(player, "§cDas Portalziel ist nicht sicher vorbereitet.");
            return;
        }

        const result = player.tryTeleport(
            { x: target.x, y: target.y, z: target.z },
            { dimension, checkForBlocks: true }
        );

        if (!result) {
            tell(player, "§cTeleportation fehlgeschlagen.");
            return;
        }

        tell(player, "§aDimensionswechsel erfolgreich.");
    } catch (error) {
        tell(player, "§cPortalfehler. Das Ziel konnte nicht erreicht werden.");
        console.warn(`[ABYSSAL] Teleport error: ${error}`);
    } finally {
        system.runTimeout(() => busyPlayers.delete(player.id), CONFIG.cooldownTicks);
    }
}

world.afterEvents.playerInteractWithBlock.subscribe((event) => {
    const { player, block } = event;

    if (!sameLocation(block, CONFIG.trigger)) return;

    const target = player.dimension.id === CONFIG.destination.dimension
        ? CONFIG.returnPoint
        : CONFIG.destination;

    teleport(player, target);
});

world.afterEvents.playerLeave.subscribe((event) => {
    busyPlayers.delete(event.playerId);
});

world.afterEvents.worldLoad.subscribe(() => {
    world.sendMessage("§5[ABYSSAL] §aPortal-Prototyp geladen.");
});
